Ishara: hettiara - 1580077
Mathew: mjbraun - 1497171

we did not collaborate with anyone else

Prerequisites:
    The following python packages must be installed using pip3:
        pip install db-utils
        pip install bsddb3

Running Instructions:
    python3 phase1.py
    python3 phase2.py
    python3 phase3.py
